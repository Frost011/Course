# Provare diversi metodi di clustering

## Istruzioni

In questa lezione si è imparato a conoscere il clustering K-Means. A volte K-Means non è appropriato per i propri dati. Creare un notebook usando i dati da queste lezioni o da qualche altra parte (accreditare la fonte) e mostrare un metodo di clustering diverso NON usando K-Means. Che cosa si è imparato?
## Rubrica

| Criteri | Ottimo | Adeguato | Necessita miglioramento |
| -------- | --------------------------------------------------------------- | -------------------------------------------------------------------- | ---------------------------- |
|          | Viene presentato un notebook con un modello di clustering ben documentato | Un notebook è presentato senza una buona documentazione e/o incompleto | E' stato inviato un lavoro incompleto |
