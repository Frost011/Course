# Provare un modello diverso

## Istruzioni

Ora che si è creato un'app web utilizzando un modello di Regressione addestrato, usare uno dei modelli da una lezione precedente sulla Regressione per rifare questa app web. Si può mantenere lo stile o progettarla in modo diverso per riflettere i dati della zucca. Fare attenzione a modificare gli input in modo che riflettano il metodo di addestramento del proprio modello.

## Rubrica

| Criteri | Ottimo | Adeguato | Necessita miglioramento |
| -------------------------- | --------------------------------------------------------- | --------------------------------------------------------- | -------------------------------------- |
| | L'app web funziona come previsto e viene distribuita nel cloud | L'app web contiene difetti o mostra risultati imprevisti | L'app web non funziona correttamente |
