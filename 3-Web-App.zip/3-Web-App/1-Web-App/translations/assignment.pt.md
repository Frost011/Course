# Tente um modelo diferente

## Instruções

Agora que você construiu um aplicativo Web usando um modelo Regression treinado, use um dos modelos de uma lição Regression anterior para refazer esse aplicativo Web. Você pode manter o estilo ou design de forma diferente para refletir os dados da abóbora. Tenha cuidado para alterar as entradas para refletir o método de treinamento do seu modelo.

## Rubrica

| Critérios                | Exemplar                                                 | Adequado                                                  | Necessidade de melhoria                  |
| -------------------------- | --------------------------------------------------------- | --------------------------------------------------------- | -------------------------------------- |
| | O aplicativo Web é executado conforme o esperado e implantado na nuvem | O aplicativo Web contém falhas ou exibe resultados inesperados | O aplicativo Web não funciona corretamente|
