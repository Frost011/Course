# Quizzes

These quizzes are the pre- and post-lecture quizzes for the ML curriculum at https://aka.ms/ml-beginners

## Project setup

```
npm install
```

### Compiles and hot-reloads for development

```
npm run serve
```

### Compiles and minifies for production

```
npm run build
```

### Lints and fixes files

```
npm run lint
```

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).

Credits: Thanks to the original version of this quiz app: https://github.com/arpan45/simple-quiz-vue
