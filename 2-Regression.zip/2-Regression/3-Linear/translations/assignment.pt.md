# Criar um modelo de regressão

## Instruções 

Nesta lição foi-lhe mostrado como construir um modelo usando a Regressão Linear e Polinomial. Utilizando este conhecimento, encontre um conjunto de dados ou use um dos conjuntos incorporados da Scikit-learn para construir um novo modelo. Explique no seu caderno porque escolheu a técnica que escolheu e demonstre a precisão do seu modelo. Se não for preciso, explique porquê.

## Rubrica

| Critérios                     |   exemplares                          | Adequado                     | Necessidades de Melhoria          |
| -------- | ------------------------------------------------------------ | -------------------------- | ------------------------------- |
|          | apresenta um caderno completo com uma solução bem documentada | a solução está incompleta| a solução é imperfeita ou buggy |
