# Riprovare un po' di Regressione

## Istruzioni

Nella lezione è stato usato un sottoinsieme dei dati della zucca. Ora si torna ai dati originali e si prova a usarli tutti, puliti e standardizzati, per costruire un modello di regressione logistica.
## Rubrica

| Criteri | Ottimo | Adeguato | Necessita miglioramento |
| -------- | ----------------------------------------------------------------------- | ------------------------------------------------------------ | ----------------------------------------------------------- |
|          | Un notebook viene presentato con un modello ben spiegato con buone prestazioni | Un notebook viene presentato con un modello dalle prestazioni minime | Un notebook viene presentato con un modello con scarse  o nessuna prestazione |
