## Retrying alguma regressão

## Instruções 

Na lição, usaste um subconjunto dos dados da abóbora. Agora, volte aos dados originais e tente usá-lo todo, limpo e padronizado, para construir uma Regressão Logística model.

## Rubrica

|  Critérios                     |   exemplares                          | Adequado                     | Necessidades de Melhoria          |
| -------- | ----------------------------------------------------------------------- | ------------------------------------------------------------ | ----------------------------------------------------------- |
|          | Um caderno é apresentado com um modelo bem explicado e bem-adundo | Um caderno é apresentado com um modelo que funciona minimamente | Um caderno é apresentado com um modelo de sub-desempenho ou nenhum|
