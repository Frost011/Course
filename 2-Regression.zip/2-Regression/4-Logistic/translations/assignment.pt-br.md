# Refazendo a regressão

## Instruções

Nesta lição, você usou um subconjunto do conjunto de dados de abóboras. Volte aos dados originais e tente usar todos eles, tratados e padronizados, para construir um modelo de Regressão Logística.

## Critérios de avaliação

| Critério | Exemplar                                                                | Adequado                                                     | Precisa melhorar                                           |
| -------- | ----------------------------------------------------------------------- | ------------------------------------------------------------ | ----------------------------------------------------------- |
|          | Apresenta um modelo bem explicado e de bom desepenho | Apresenta um modelo com desempenho mínimo | Apresenta um modelo baixo desempenho |
