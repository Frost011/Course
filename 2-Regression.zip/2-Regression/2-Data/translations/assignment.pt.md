# Exploração de Visualizações

Existem várias bibliotecas diferentes que estão disponíveis para visualização de dados. Crie algumas visualizações utilizando os dados da Abóbora nesta lição com matplotlib e nascidos num caderno de amostras. Com que bibliotecas é mais fácil de trabalhar?

## Rubrica

 Critérios                      |   exemplares                          | Adequado                     | Necessidades de Melhoria          |
| -------- | --------- | -------- | ----------------- |
|          | Um caderno é submetido com duas explorações/visualizações|   Um caderno é submetido com uma exploração/visualizações     |  Um caderno não é submetido               |
