# Explorando Visualizações

## Instruções

Existem muitas bibliotecas disponíveis para visualização de dados. Crie algumas visualizações usando o conjunto de dados sobre abóboras nesta lição usando matplotlib e seaborn em um _notebook_. Quais bibliotecas são mais fáceis de usar?

## Critérios de avaliação

| Critério | Exemplar | Adequado | Precisa melhorar |
| -------- | --------- | -------- | ----------------- |
|          | Um _notebook_ foi submetido com duas explorações/visualizações         |   Um _notebook_ foi submetido com uma exploração/visualização     |  Nenhum _notebook_ foi submetido                 |
