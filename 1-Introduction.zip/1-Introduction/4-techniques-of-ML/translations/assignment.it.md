# Intervista a un data scientist

## Istruzioni

Nella propria azienda, in un gruppo di utenti, o tra amici o compagni di studio, si parli con qualcuno che lavora professionalmente come data scientist. Si scriva un breve documento (500 parole) sulle loro occupazioni quotidiane. Sono specialisti o lavorano "full stack"?

## Rubrica

| Criteri | Ottimo | Adeguato | Necessita miglioramento |
| -------- | ------------------------------------------------------------------------------------ | ------------------------------------------------------------------ | --------------------- |
|          | Un saggio della lunghezza corretta, con fonti attribuite, è presentato come file .doc | Il saggio è attribuito male o più corto della lunghezza richiesta | Non viene presentato alcun saggio |
