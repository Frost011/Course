# Entreviste uma pessoa cientista de dados

## Instructions

Em sua empresa, em um grupo de usuários ou entre seus amigos ou colegas estudantes, converse com alguém que trabalhe profissionalmente como cientista de dados. Escreva um pequeno artigo (500 palavras) sobre suas ocupações diárias. Eles são especialistas ou trabalham com 'full stack'?

## Rubrica

| Critérios | Exemplar                                                                            | Adapte                                                           | Precisa Melhorar     |
| -------- | ------------------------------------------------------------------------------------ | ------------------------------------------------------------------ | --------------------- |
|          | Uma redação com a extensão correta, com fontes atribuídas, é apresentado em arquivo .doc | A redação está mal atribuído ou é menor do que o comprimento exigido | Nenhuma redação é apresentado | |
