# Entrevista a un científico de datos

## Instrucciones

En tu compañía, en un grupo de usuarios, o entre tus amigos o compañeros de estudio, habla con alguien que trabaje profesionalmente como científico de datos. Escribe un artículo corto (500 palabras) acerca de sus ocupaciones diarias. ¿Son ellos especialistas, o trabajan como 'full stack'?

## Rúbrica

| Criterio | Ejemplar                                                                            | Adecuado                                                           | Necesita mejorar     |
| -------- | ------------------------------------------------------------------------------------ | ------------------------------------------------------------------ | --------------------- |
|          | Un ensayo de la longitud correcta, con fuentes atribuidas, es presentado como un archivo .doc | El ensayo es pobremente atribuido o más corto que la longitud requerida | No se presentó el ensayo |
