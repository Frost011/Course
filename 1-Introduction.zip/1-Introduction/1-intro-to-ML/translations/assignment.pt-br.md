# Comece a Trabalhar

## Instruções

Nesta tarefa não corrigida, você deve se aprimorar em Python e colocar seu ambiente em funcionamento e capaz de executar notebooks.

Faça o [Caminho de aprendizagem do Python](https://docs.microsoft.com/learn/paths/python-language/?WT.mc_id=academic-15963-cxa), e, em seguida, faça a configuração de seus sistemas analisando estes vídeos introdutórios:

https://www.youtube.com/playlist?list=PLlrxD0HtieHhS8VzuMCfQD4uJ9yne1mE6
