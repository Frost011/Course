# 启动和运行

## 说明

在这个不评分的作业中，你应该温习一下 Python，将 Python 环境能够运行起来，并且可以运行 notebooks。

学习这个 [Python 学习路径](https://docs.microsoft.com/learn/paths/python-language/?WT.mc_id=academic-15963-cxa)，然后通过这些介绍性的视频将你的系统环境设置好：

https://www.youtube.com/playlist?list=PLlrxD0HtieHhS8VzuMCfQD4uJ9yne1mE6
