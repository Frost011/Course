# 稼働させる

## 指示

この評価のない課題では、Pythonについて復習し、環境を稼働させてノートブックを実行できるようにする必要があります。

この[Pythonラーニングパス](https://docs.microsoft.com/learn/paths/python-language/?WT.mc_id=academic-15963-cxa)を受講し、次の入門用ビデオに従ってシステムをセットアップしてください。

https://www.youtube.com/playlist?list=PLlrxD0HtieHhS8VzuMCfQD4uJ9yne1mE6
