# Tempi di apprendimento brevi

## Istruzioni

In questo compito senza valutazione, si dovrebbe rispolverare Python e rendere il proprio ambiente attivo e funzionante, in grado di eseguire notebook.

Si segua questo [percorso di apprendimento di Python](https://docs.microsoft.com/learn/paths/python-language/?WT.mc_id=academic-15963-cxa) e quindi si configurino i propri sistemi seguendo questi video introduttivi:

https://www.youtube.com/playlist?list=PLlrxD0HtieHhS8VzuMCfQD4uJ9yne1mE6
