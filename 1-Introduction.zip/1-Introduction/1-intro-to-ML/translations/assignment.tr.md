# Haydi Başlayalım

## Talimatlar

Bu not-verilmeyen ödevde, Python bilgilerinizi tazelemeli, geliştirme ortamınızı çalışır duruma getirmeli ve not defterlerini çalıştırabilmelisiniz.

Bu [Python Eğitim Patikasını](https://docs.microsoft.com/learn/paths/python-language/?WT.mc_id=academic-15963-cxa) bitirin ve ardından bu tanıtım videolarını izleyerek sistem kurulumunuzu yapın :

https://www.youtube.com/playlist?list=PLlrxD0HtieHhS8VzuMCfQD4uJ9yne1mE6