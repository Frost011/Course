# 시작해 봅시다

## 설명

이 미채점 과제에서는 파이썬(Python)을 복습하고 Python 실행 환경 설정 및 노트북(Jupyter Notebook) 실행 방법까지 숙지해 보시길 바랍니다.

다음 [Python Learning Path](https://docs.microsoft.com/learn/paths/python-language/?WT.mc_id=academic-15963-cxa)를 이수하시고, 아래 Python 입문 강좌를 통해 Python 설치 및 실행 환경을 설정해 보세요:

https://www.youtube.com/playlist?list=PLlrxD0HtieHhS8VzuMCfQD4uJ9yne1mE6
