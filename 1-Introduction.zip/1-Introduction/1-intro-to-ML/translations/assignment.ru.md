# Настройте среду разработки

## Инструкции

Это задание не оценивается. Вы должны освежить в памяти Python и настроить свою среду, чтобы она могла запускать ноутбуки.

Воспользуйтесь этим курсом [Python Learning Path](https://docs.microsoft.com/learn/paths/python-language/?WT.mc_id=academic-15963-cxa), а затем настройте свою систему, просмотрев эти вводные видео:

https://www.youtube.com/playlist?list=PLlrxD0HtieHhS8VzuMCfQD4uJ9yne1mE6
