# Explore Fairlearn

## Instruções

Nesta lição, você aprendeu sobre o Fairlearn, um "projeto de código aberto voltado para a comunidade para ajudar os cientistas de dados a melhorar a justiça dos sistemas de IA". Para esta tarefa, explore um do [notebooks](https://fairlearn.org/v0.6.2/auto_examples/index.html) e relate suas descobertas em um artigo ou apresentação.

## Rubrica

| Critérios | Exemplar | Adapte | Precisa Melhorar |
| -------- | --------- | -------- | ----------------- |
|          |  Uma apresentação em papel ou em PowerPoint é apresentada discutindo os sistemas da Fairlearn, o bloco de notas que foi executado e as conclusões tiradas de sua execução       |   Um artigo é apresentado sem conclusões       |  Nenhum artigo é apresentado                 |
