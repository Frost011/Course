# Explore Fairlearn

## Instrucciones

En esta lección, aprendió sobre Fairlearn, un "proyecto open-source impulsado por la comunidad para ayudar a los científicos de datos a mejorar la equidad de los sistemas de AI." Para esta tarea, explore uno de los  [cuadernos](https://fairlearn.org/v0.6.2/auto_examples/index.html) de Fairlearn e informe sus hallazgos en un documento o presentación.

## Rúbrica

| Criterios | Ejemplar | Adecuado | Necesita mejorar |
| -------- | --------- | -------- | ----------------- |
|          |  Un documento o presentación powerpoint es presentado discutiendo los sistemas de Fairlearn, el cuaderno que fue ejecutado, y las conclusiones extraídas al ejecutarlo        |   Un documento es presentado sin conclusiones       |  No se presenta ningún documento    |
