# Membuat sebuah *timeline*

## Instruksi

Menggunakan [repo ini](https://github.com/Digital-Humanities-Toolkit/timeline-builder), buatlah sebuah *timeline* dari beberapa aspek sejarah algoritma, matematika, statistik, AI, atau ML, atau kombinasi dari semuanya. Kamu dapat fokus pada satu orang, satu ide, atau rentang waktu pemikiran yang panjang. Pastikan untuk menambahkan elemen multimedia. 

## Rubrik

| Kriteria | Sangat Bagus                                         | Cukup                                | Perlu Peningkatan                                                |
| -------- | ------------------------------------------------- | --------------------------------------- | ---------------------------------------------------------------- |
|          | *Timeline* yang dideploy disajikan sebagai halaman GitHub | Kode belum lengkap dan belum dideploy | *Timeline* belum lengkap, belum diriset dengan baik dan belum dideploy |