# Crie uma linha do tempo

## Instruções

Usando [este repositório](https://github.com/Digital-Humanities-Toolkit/timeline-builder), crie uma linha do tempo de algum aspecto da história de algoritmos, matemática, estatística, AI ou ML, ou uma combinação de esses. Você pode se concentrar em uma pessoa, uma ideia ou um longo período de pensamento. Certifique-se de adicionar elementos de multimídia.

## Rubrica

| Critérios | Exemplar                                         | Adequado                                | Precisa Melhorar                                                |
| -------- | ------------------------------------------------- | --------------------------------------- | ---------------------------------------------------------------- |
|          | Um cronograma implantado é apresentado como uma página do GitHub (GitHub Page) | O código está incompleto e não implementado | O cronograma está incompleto, não foi bem pesquisado e não implantado |