# Bir zaman çizelgesi oluşturun

## Talimatlar

[Bu repoyu](https://github.com/Digital-Humanities-Toolkit/timeline-builder) kullanarak; algoritmaların, matematiğin, istatistiğin, AI veya ML'in veya bunların bir kombinasyonunun tarihinin bazı yönlerinin bir zaman çizelgesini oluşturun. Bir kişiye, bir fikre veya bir düşüncenin uzun bir zamanına odaklanabilirsiniz. Multimedya öğeleri eklediğinizden emin olun.

## Değerlendirme Listesi

|  | Takdir edilesi                                         | Yeterli                                | İyileştirilmesi Lazım                                                |
| -------- | ------------------------------------------------- | --------------------------------------- | ---------------------------------------------------------------- |
|     Kriterler     | Zaman çizelgesi bir GitHub sayfası olarak yayınlanmış | Kod eksik ve henüz yayınlanmamış | Zaman çizelgesi eksik, iyi araştırılmamış ve yayınlanmamış |