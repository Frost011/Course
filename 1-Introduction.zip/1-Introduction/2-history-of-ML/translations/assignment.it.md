# Creare una sequenza temporale

## Istruzioni

Usando [questo repository](https://github.com/Digital-Humanities-Toolkit/timeline-builder), si crei una sequenza temporale di alcuni aspetti della storia di algoritmi, matematica, statistica, AI o ML, o una combinazione di questi. Ci si può concentrare su una persona, un'idea o un lungo lasso di tempo di pensiero. Ci si assicuri di aggiungere elementi multimediali.

## Rubrica

| Criteri | Ottimo | Adeguato | Necessita miglioramento |
| -------- | ------------------------------------------------- | --------------------------------------- | ---------------------------------------------------------------- |
|          | Una sequenza temporale distribuita viene presentata come una pagina GitHub | Il codice è incompleto e non è stato distribuito | La sequenza temporale è incompleta, non ben studiata e non implementata |
