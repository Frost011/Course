# Crea una línea de tiempo

## Instrucciones

Usando [este repositorio](https://github.com/Digital-Humanities-Toolkit/timeline-builder), crea una línea temporal de algunos aspectos de la historia de los algoritmos, matemáticas, estadística, Inteligencia Artificial (AI), Aprendizaje Automático (ML), o una combinación de todos estos. Te puedes enfocar en una persona, una idea o período largo de tiempo de pensamiento. Asegúrate de agregar elementos multimedia.

## Rúbrica

| Criterio | Ejemplar                                         | Adecuado                                | Necesita mejorar                                                |
| -------- | ------------------------------------------------- | --------------------------------------- | ---------------------------------------------------------------- |
|          | Una línea de tiempo desplegada es representada como una página de Github | El código está incompleto y no fue desplegado | La línea del tiempo está incompleta, sin buena investigación y sin desplegar |
