# Çözücüleri çalışın
## Yönergeler

Bu derste, doğru bir model yaratmak için algoritmaları bir makine öğrenimi süreciyle eşleştiren çeşitli çözücüleri öğrendiniz. Derste sıralanan çözücüleri inceleyin ve iki tanesini seçin. Kendi cümlelerinizle, bu iki çözücünün benzerliklerini ve farklılıklarını bulup yazın. Ne tür problemleri ele alıyorlar? Çeşitli veri yapılarıyla nasıl çalışıyorlar? Birini diğerine neden tercih ederdiniz?
## Rubrik

|  Ölçüt   | Örnek Alınacak Nitelikte                                                                                             | Yeterli                                          | Geliştirme Gerekli           |
| -------- | -------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------ | ---------------------------- |
|          | Her biri bir çözücü üzerine yazılmış, onları dikkatle karşılaştıran ve iki paragraf içeren bir .doc dosyası sunulmuş | Bir paragraf içeren bir .doc dosyası sunulmuş    | Görev tamamlanmamış          |
