# Bir önerici oluşturun

## Yönergeler

Bu dersteki alıştırmalar göz önünde bulundurulursa, Onnx Runtime ve dönüştürülmüş bir Onnx modeli kullanarak JavaScript tabanlı web uygulamasının nasıl oluşturulacağını artık biliyorsunuz. Bu derslerdeki verileri veya başka bir yerden kaynaklandırılmış verileri (Lütfen kaynakça verin.) kullanarak yeni bir önerici oluşturma deneyimi kazanın. Verilen çeşitli kişilik özellikleriyle bir evcil hayvan önericisi veya kişinin ruh haline göre bir müzik türü önericisi oluşturabilirsiniz. Yaratıcı olun!

## Rubrik

|  Ölçüt   | Örnek Alınacak Nitelikte                                               | Yeterli                               | Geliştirme Gerekli                |
| -------- | ---------------------------------------------------------------------- | ------------------------------------- | --------------------------------- |
|          | İyi belgelenen ve çalışan bir web uygulaması ve not defteri sunulmuş   | İkisinden biri eksik veya kusurlu     | İkisi ya eksik ya da kusurlu      |