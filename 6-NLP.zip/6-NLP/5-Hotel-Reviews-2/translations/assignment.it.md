# Provare un insieme di dati diverso

## Istruzioni

Ora che si è imparato a usare NLTK per assegnare sentiment al testo, provare un insieme di dati diverso. Probabilmente si dovranno elaborare dei dati attorno ad esso, quindi creare un notebook e documentare il proprio processo di pensiero. Cosa si è scoperto?

## Rubrica

| Criteri | Ottimo | Adeguato | Necessita miglioramento |
| -------- | ----------------------------------------------------------------------------------------------------------------- | ----------------------------------------- | ---------------------- |
|          | Vengono presentati un notebook completo e un insieme di dati con celle ben documentate che spiegano come viene assegnato il sentiment | Il notebook manca di buone spiegazioni | Il notebook è difettoso |
