# Licenza poetica

## Istruzioni

In [questo notebook](https://www.kaggle.com/jenlooper/emily-dickinson-word-frequency) si possono trovare oltre 500 poesie di Emily Dickinson precedentemente analizzate per il sentiment utilizzando l'analisi del testo di Azure. Utilizzando questo insieme di dati, analizzarlo utilizzando le tecniche descritte nella lezione. Il sentimento suggerito di una poesia corrisponde alla decisione più sofisticata del servizio Azure? Perché o perché no, secondo il proprio parere? C’è qualcosa che sorprende?

## Rubrica

| Criteri | Ottimo | Adeguato | Necessita miglioramento |
| -------- | -------------------------------------------------------------------------- | ------------------------------------------------------- | ------------------------ |
|          | Un notebook viene presentato con una solida analisi del risultato da un campione di un autore | Il notebook è incompleto o non esegue l'analisi | Nessun notebook presentato |
