# Cercare un bot

## Istruzioni

I bot sono ovunque. Il compito: trovarne uno e adottarlo! È possibile trovarli sui siti web, nelle applicazioni bancarie e al telefono, ad esempio quando si chiamano società di servizi finanziari per consigli o informazioni sull'account. Analizzare il bot e vedire se si riesce a confonderlo. Se si riesce a confondere il bot, perché si pensa sia successo? Scrivere un breve articolo sulla propria esperienza.

## Rubrica

| Criteri | Ottimo | Adeguato | Necessita miglioramento |
| -------- | ------------------------------------------------------------------------------------------------------------- | -------------------------------------------- | --------------------- |
|          | Viene scritto un documento a pagina intera, che spiega la presunta architettura del bot e delinea l'esperienza con esso | Un documento è incompleto o non ben concepito | Nessun documento inviato |
